import requests

from data import error_messages


def access_api(url, parameter, error_message, headers=None):
    if headers:
        raw = requests.get(url, headers=headers)
    else:
        raw = requests.get(url)
    if raw.status_code == 200:
        try:
            data = raw.json()
            response = data[parameter]
        except (requests.exceptions.JSONDecodeError, KeyError):
            response = str(f"{error_message}")
        except Exception as e:
            response = str(f"{error_message} (Error {str(e)})")
    else:
        response = str(f"{error_message} (HTTP {raw.status_code})")

    return response


# ---------- Commands ----------
def quote():
    quote_response = requests.get("https://zenquotes.io/api/random")
    try:
        data = quote_response.json()
        fetched_quote = data[0]["q"]
        author = data[0]["a"]
        response = f"""{fetched_quote}\n~{author}"""
    except (requests.exceptions.JSONDecodeError, KeyError, IndexError):
        response = error_messages["quote"]
    return response


def meme():
    return access_api("https://meme-api.com/gimme", "url", error_messages["meme"])


def waifu():
    waifu1 = access_api(
        "https://api.waifu.pics/sfw/waifu", "url", error_messages["waifu"]
    )
    waifu2 = access_api(
        "https://api.waifu.pics/sfw/waifu", "url", error_messages["waifu"]
    )
    return f"""### Which one is better?

    {waifu1}
    {waifu2}"""


def duck():
    return access_api("https://random-d.uk/api/random", "url", error_messages["duck"])


def dog():
    return access_api("https://random.dog/woojson", "url", error_messages["dog"])


def cat():
    raw = requests.get("https://api.thecatapi.com/v1/images/search")
    if raw.status_code == 200:
        try:
            data = raw.json()
            response = data[0]["url"]
        except (requests.exceptions.JSONDecodeError, KeyError, IndexError):
            response = error_messages["cat"]
    else:
        response = error_messages["cat"]
    return response


def chuck():
    return access_api(
        "https://api.chucknorris.io/jokes/random", "value", error_messages["chuck"]
    )


def fact():
    return access_api(
        "https://uselessfacts.jsph.pl/api/v2/facts/random",
        "text",
        error_messages["fact"],
    )


def bible(
    is_random, book_arg: str = "John", chapter_arg: int = 16, verse_arg: int = 32
):

    if is_random:
        url = "https://bible-api.com/data/web/random"
    else:
        url = f"https://bible-api.com/{book_arg} {chapter_arg}:{verse_arg}"

    bible_response = requests.get(url)
    if bible_response.status_code == 200:
        try:
            data = bible_response.json()
            if "random_verse" in data:
                verse = data["random_verse"]
                response = f"{verse['text']}\n{verse['book']} {verse['chapter']}:{verse['verse']}"
            elif "text" in data and "reference" in data:
                response = f"{data['text']}\n{data['reference']}"
            else:
                response = error_messages["passage_not_found"].replace(
                    r"{{PASSAGE}}", f"{book_arg} {chapter_arg}:{verse_arg}"
                )
        except (requests.exceptions.JSONDecodeError, KeyError):
            response = error_messages["bible"]
    elif bible_response.status_code == 404:
        response = error_messages["passage_not_found"].replace(
            r"{{PASSAGE}}", f"{book_arg} {chapter_arg}:{verse_arg}"
        )
    else:
        response = f"{error_messages['bible']} (HTTP {bible_response.status_code})"
    return response


def bitcoin(currency_parameter):
    currency = currency_parameter.lower() if len(str(currency_parameter)) > 1 else "usd"
    bitcoin_price = requests.get(
        f"https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies={currency}"
    )
    if bitcoin_price.status_code == 200:
        data = bitcoin_price.json()
        if "bitcoin" in data and currency in data["bitcoin"]:
            response = f"bitcoin is at {data['bitcoin'][currency]} {currency} rn"
        else:
            response = error_messages["currency"]
    else:
        response = error_messages["bitcoin"]
    return response


def tord(url, rating, max_retries=10):
    for _ in range(max_retries):
        response = requests.get(url)
        if response.status_code != 200:
            continue
        data = response.json()
        if not rating or data.get("rating") == rating:
            return data["question"]
    return None


def joke():
    raw = requests.get("https://official-joke-api.appspot.com/jokes/random")
    if raw.status_code == 200:
        try:
            data = raw.json()
            response = f"{data['setup']} ||{data['punchline']}||"
        except (requests.exceptions.JSONDecodeError, KeyError):
            response = error_messages["joke"]
    else:
        response = error_messages["joke"]
    return response


def currency(currency1, currency2, amount):
    try:
        amount = float(amount)
    except (TypeError, ValueError):
        return error_messages["currency"]

    currency1 = currency1.lower()
    currency2 = currency2.lower()

    available_currencies = requests.get(
        "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies.json"
    )

    if available_currencies.status_code != 200:
        return error_messages["unavailable"]

    available_currencies = available_currencies.json()

    if currency1 not in available_currencies:
        return f"{error_messages['currency']} ({currency1})"
    if currency2 not in available_currencies:
        return f"{error_messages['currency']} ({currency2})"

    raw_response = requests.get(
        f"https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/{currency1}.json"
    )

    if raw_response.status_code != 200:
        return error_messages["unavailable"]

    raw_response = raw_response.json()

    if currency1 not in raw_response or currency2 not in raw_response[currency1]:
        return error_messages["currency"]

    rate = raw_response[currency1][currency2]
    response = rate * amount
    return f"{amount} {currency1.upper()} = {response:.2f} {currency2.upper()}"
